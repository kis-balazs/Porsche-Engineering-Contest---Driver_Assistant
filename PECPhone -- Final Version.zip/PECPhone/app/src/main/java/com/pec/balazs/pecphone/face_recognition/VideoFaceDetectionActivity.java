package com.pec.balazs.pecphone.face_recognition;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.MultiProcessor;
import com.google.android.gms.vision.Tracker;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.pec.balazs.pecphone.MainActivity;
import com.pec.balazs.pecphone.R;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

public class VideoFaceDetectionActivity extends AppCompatActivity {

    private CameraPreview mPreview;
    private GraphicOverlay mGraphicOverlay;
    private CameraSource mCameraSource = null;

    private static final int REQUEST_CAMERA_PERMISSION = 1;
    private static final int RC_HANDLE_GMS = 2;

    TextView v;

    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    String extDataNoDisruption = "0\t15\t14\t11\t13\t11\t14\t14\t11\t16\t14\t9\t14\t14\t14\t14\t16\t13\t13\t13\t14\t14\t16\t12\t14\t14\t11\t14\t13\t14\t15\t13\t14\t14\t13\t11\t12\t13\t12\t11\t15\t11\t12\t11\t13\t15\t13\t11\t13\t15\t13\t12\t13\t11\t12\t12\t13\t14\t13\t11\t13\t13\t10\t13\t14\t10\t14\t13\t12\t13\t12\t11\t12\t13\t10\t11\t13\t12\t13\t12\t12\t14\t15\t10\t13\t15\t13\t12\t11\t8\t10\t11\t10\t11\t11\t13\t10\t11\t8\t10\t12\t10\t11\t11\t11\t11\t12\t9\t12\t13\t11\t11\t10\t12\t12\t12\t11\t13\t12\t10\t13\t14\t14\t13\t13\t10\t14\t14\t10\t11\t11\t10\t13\t13\t10\t11\t14\t10\t10\t9\t10\t12\t11\t9\t12\t11\t10\t10\t11\t10\t9\t8\t8\t8\t8\t6\t9\t9\t9\t8\t10\t7\t9\t8\t9\t11\t11\t8\t10\t12\t12\t12\t14\t13\t16\t12\t13\t15\t12\t8\t14\t16\t13\t14\t14\t12\t15\t11\t13\t13\t13\t10\t15\t14\t14\t13\t14\t13\t14\t15\t16\t15\t15\t15\t16\t14\t15\t13\t14\t13\t16\t15\t14\t17\t15\t12\t15\t16\t12\t15\t16\t13\t19\t17\t17\t19\t15\t14\t15\t17\t15\t13\t15\t13\t15\t16\t12\t15\t16\t13\t15\t15\t13\t14\t14\t14\t14\t12\t11\t13\t13\t12\t15\t15\t15\t14\t15\t16\t15\t14\t13\t13\t13\t13\t13\t14\t13\t15\t17\t9\t15\t16\t12\t15\t15\t11\t14\t16\t14\t15\t15\t11\t15\t15\t13\t14\t15\t13\t16\t14\t14\t13\t13\t12\t13\t15\t14\t15\t15\t11\t15\t14";
    String extDataDisruption = "0\t19\t17\t15\t16\t19\t20\t19\t17\t21\t19\t22\t20\t19\t17\t17\t19\t20\t16\t15\t18\t19\t16\t18\t19\t20\t15\t15\t13\t19\t18\t15\t16\t14\t14\t15\t13\t12\t11\t9\t10\t13\t14\t13\t13\t12\t8\t8\t9\t10\t11\t9\t7\t10\t8\t11\t10\t10\t12\t8\t8\t10\t10\t10\t10\t13\t9\t12\t17\t17\t19\t19\t18\t20\t16\t13\t16\t18\t14\t13\t14\t14\t12\t14\t13\t13\t12\t12\t12\t10\t12\t10\t13\t14\t14\t13\t11\t15\t13\t11\t9\t11\t9\t11\t11\t12\t10\t11\t11\t12\t13\t13\t11\t12\t10\t10\t12\t13\t11\t11\t8\t11\t10\t8\t8\t13\t9\t12\t12\t13\t13\t11\t11\t14\t12\t11\t10\t10\t9\t9\t9\t9\t8\t9\t9\t10\t9\t10\t6\t7\t7\t6\t7\t8\t4\t7\t3\t4\t5\t4\t4\t5\t4\t9";
    public int iter;
    String[] noDisr, disr;
    public static double res = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(MainActivity.EXTRA_ADDRESS);

        setContentView(R.layout.activity_video_face_detection);

        v = findViewById(R.id.tv);

        mPreview = findViewById(R.id.preview);
        mGraphicOverlay = findViewById(R.id.faceOverlay);

        new ConnectBT().execute();

        noDisr = extDataNoDisruption.split("\t");
        disr = extDataDisruption.split("\t");


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // permission not granted, initiate request
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            createCameraSource();
        }
        // started
        iter = 0;
        v.setText("if you see this my implementation is very bad");
        runContinuously();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CAMERA_PERMISSION && resultCode == RESULT_OK) {
            createCameraSource();
        }
    }

    private void createCameraSource() {
        Context context = getApplicationContext();
        FaceDetector detector = new FaceDetector.Builder(context)
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS)
                .build();

        detector.setProcessor(
                new MultiProcessor.Builder<>(new GraphicFaceTrackerFactory())
                        .build());

        mCameraSource = new CameraSource.Builder(context, detector)
                .setRequestedPreviewSize(640, 480)
                .setFacing(CameraSource.CAMERA_FACING_FRONT)
                .setRequestedFps(30.0f)
                .build();
    }

    /**
     * Restarts the camera.
     */
    @Override
    protected void onResume() {
        super.onResume();
        startCameraSource();
    }

    /**
     * Stops the camera.
     */
    @Override
    protected void onPause() {
        super.onPause();
        mPreview.stop();
    }

    /**
     * Releases the resources associated with the camera source, the associated detector, and the
     * rest of the processing pipeline.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mCameraSource != null) {
            mCameraSource.release();
        }
    }

    private void startCameraSource() {
        // check that the device has play services available.
        int code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(getApplicationContext());
        if (code != ConnectionResult.SUCCESS) {
            Dialog dlg = GoogleApiAvailability.getInstance().getErrorDialog(this, code, RC_HANDLE_GMS);
            dlg.show();
        }
        if (mCameraSource != null) {
            try {
                mPreview.start(mCameraSource, mGraphicOverlay);
            } catch (IOException e) {
                mCameraSource.release();
                mCameraSource = null;
            }
        }
    }

    /**
     * Factory for creating a face tracker to be associated with a new face.  The multiprocessor
     * uses this factory to create face trackers as needed -- one for each individual.
     */
    private class GraphicFaceTrackerFactory implements MultiProcessor.Factory<Face> {
        @Override
        public Tracker<Face> create(Face face) {
            return new GraphicFaceTracker(mGraphicOverlay, getBaseContext().getApplicationContext());
        }
    }

    public static String getFromPrefs(Context context, String key, String defaultValue) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        try {
            return sharedPrefs.getString(key, defaultValue);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    public static void removeFromPrefs(Context context, String key) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = prefs.edit();
        editor.remove(key);
        editor.commit();
    }

    public static String getRes() {
        return res + "";
    }

    public void loadPrevValues() {
        int id = Integer.parseInt(getFromPrefs(getBaseContext(), "id", "0"));
        removeFromPrefs(getBaseContext(), "id");
        float smile = Float.parseFloat(getFromPrefs(getBaseContext(), "smile", "0"));
        removeFromPrefs(getBaseContext(), "smile");
        float le = Float.parseFloat(getFromPrefs(getBaseContext(), "le", "0"));
        removeFromPrefs(getBaseContext(), "le");
        float re = Float.parseFloat(getFromPrefs(getBaseContext(), "re", "0"));
        removeFromPrefs(getBaseContext(), "re");

        int leClosed, reClosed;
        int smiling;

        leClosed = Math.round(le * 100);
        reClosed = Math.round(re * 100);
        smiling = Math.round(smile * 100);

        iter++;
        res = (leClosed + reClosed + smiling ) * 1.0 / 2.5 - 2.0 * Float.parseFloat(noDisr[iter % noDisr.length]);
        v.setTextColor(Color.BLACK);
        v.setTextSize(15);
        v.setText("Overall score: " + (res < 0 ? 0 : res));
        if (res <= 25)
            sendSignal("0");
        else if (res > 25 && res < 60)
            sendSignal("1");
        else
            sendSignal("2");
    }

    // 60 FPS -- double of the normal speed => 500ms
    final void runContinuously() {
        final Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loadPrevValues();
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                            }
                        }, 500);
                    }
                });
            }
        }, 0, 500);
    }
    private void sendSignal ( String number ) {
        if ( btSocket != null ) {
            try {
                btSocket.getOutputStream().write(number.toString().getBytes());
            } catch (IOException e) {
            }
        }
    }

    private void Disconnect () {
        if ( btSocket!=null ) {
            try {
                btSocket.close();
            } catch(IOException e) {
                msg("Error");
            }
        }
        finish();
    }

    private void msg (String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
    }

    private class ConnectBT extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;

        @Override
        protected  void onPreExecute () {
            progress = ProgressDialog.show(VideoFaceDetectionActivity.this, "Connecting...", "Please Wait!!!");
        }

        @Override
        protected Void doInBackground (Void... devices) {
            try {
                if ( btSocket==null || !isBtConnected ) {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();
                }
            } catch (IOException e) {
                ConnectSuccess = false;
            }

            return null;
        }

        @Override
        protected void onPostExecute (Void result) {
            super.onPostExecute(result);

            if (!ConnectSuccess) {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            } else {
                msg("Connected");
                isBtConnected = true;
            }

            progress.dismiss();
        }
    }
}
