package com.pec.balazs.pecphone.externalDataHandling;


import java.io.*;
import java.util.*;

public class CoordinateFetch {
    public static List<String> takeOutValues(String str) {
        List<String> lst = new ArrayList<String>();
        String[] values = str.split("(?=\\,)");
        int i = 0;
        for (i = 0; i < values.length; i++) {
            if (i == 1 || i == 2 || i == 3 || i == 4) {
                System.out.print(values[i].replaceAll("[ ,]", "") + "; ");
                lst.add(values[i].replaceAll("[ ,]", ""));
            }
        }
        return lst;
    }

    public static List<String> sumOfObjects(String str) {
        List<String> lst = new ArrayList<String>();
        String[] values = str.split("	");
        int i = 0;
        for (i = 0; i < values.length; i++) {
            lst.add(values[i].replaceAll("[ ]", ""));
        }
        return lst;
    }

    public static void main(String[] args) throws IOException {
        Scanner objectCnt = null;
        Scanner objects = null;
        try {
            objectCnt = new Scanner(new File("disruptionObjectCount.txt"));
            objects = new Scanner(new File("disruptionCoordinates.txt"));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // car and person
        System.out.println(objectCnt.nextLine());

        String strToWrite;
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter("objects.txt"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        int cnt = 0;
        while (objectCnt.hasNextLine()) {
            List <String> obj = sumOfObjects(objectCnt.nextLine());
            int objc = Integer.parseInt(obj.get(0)) + Integer.parseInt(obj.get(1));
            if (cnt % 2 == 1)
                objc--;
            writer.write((objc) + "");
            writer.newLine();
            int i = 0;
            while (i < objc * 2 - 1) {
                List <String> vals = takeOutValues(objects.nextLine());
                for(String val : vals) {
                    try {
                        float print = Float.parseFloat(val);
                        writer.write(print + "");
                    } catch(NumberFormatException e) {
                        writer.write("");
                    }
                    writer.write(" ");
                }
                i++;
                writer.newLine();
            }
            cnt++;
        }
        try {
            writer.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
