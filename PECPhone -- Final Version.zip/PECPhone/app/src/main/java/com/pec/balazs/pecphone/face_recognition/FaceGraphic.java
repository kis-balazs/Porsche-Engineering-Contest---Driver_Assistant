package com.pec.balazs.pecphone.face_recognition;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.preference.PreferenceManager;

import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.Landmark;

class FaceGraphic extends GraphicOverlay.Graphic {

    Context cont;

    private static final float FACE_POSITION_RADIUS = 10.0f;
    private static final float ID_TEXT_SIZE = 40.0f;
    private static final float ID_Y_OFFSET = 50.0f;
    private static final float ID_X_OFFSET = -50.0f;
    private static final float BOX_STROKE_WIDTH = 5.0f;

    private Paint mFacePositionPaint;
    private Paint mIdPaint;
    private Paint mBoxPaint;

    private volatile Face mFace;
    private int mFaceId;

    // variables for sampling
    private float smile = 0, le = 0, re = 0, z = 0;
    private int i = 0;

    FaceGraphic(GraphicOverlay overlay, Context ctx) {
        super(overlay);
        final int selectedColor = Color.WHITE;

        this.cont = ctx;

        mFacePositionPaint = new Paint();
        mFacePositionPaint.setColor(selectedColor);

        mIdPaint = new Paint();
        mIdPaint.setColor(selectedColor);
        mIdPaint.setTextSize(ID_TEXT_SIZE);

        mBoxPaint = new Paint();
        mBoxPaint.setColor(selectedColor);
        mBoxPaint.setStyle(Paint.Style.STROKE);
        mBoxPaint.setStrokeWidth(BOX_STROKE_WIDTH);
    }

    void setId(int id) {
        mFaceId = id;
    }

    /**
     * Updates the face instance from the detection of the most recent frame.  Invalidates the
     * relevant portions of the overlay to trigger a redraw.
     */
    void updateFace(Face face) {
        mFace = face;
        postInvalidate();
    }

    /**
     * Draws the face annotations for position on the supplied canvas.
     */
    @Override
    public void draw(Canvas canvas) {
        Face face = mFace;
        if (face == null) {
            return;
        }

        // Draws a circle at the position of the detected face, with the face's track id below.
        float x = translateX(face.getPosition().x + face.getWidth() / 2);
        float y = translateY(face.getPosition().y + face.getHeight() / 2);
        canvas.drawCircle(x, y, FACE_POSITION_RADIUS, mFacePositionPaint);
        canvas.drawText("id: " + mFaceId, x + ID_X_OFFSET, y + ID_Y_OFFSET, mIdPaint);

        // Draws a bounding box around the face.
        float xOffset = scaleX(face.getWidth() / 2.0f);
        float yOffset = scaleY(face.getHeight() / 2.0f);
        float left = x - xOffset;
        float top = y - yOffset;
        float right = x + xOffset;
        float bottom = y + yOffset;
        canvas.drawRect(left, top, right, bottom, mBoxPaint);

        // Draws a circle for each face feature detected
        for (Landmark landmark : face.getLandmarks()) {
            // the preview display of front-facing cameras is flipped horizontally
            float cx = canvas.getWidth() - scaleX(landmark.getPosition().x);
            float cy = scaleY(landmark.getPosition().y);
            canvas.drawCircle(cx, cy, 10, mIdPaint);
        }
        fillFaceValues(canvas, face);
    }

    public void fillFaceValues(Canvas c, Face e) {
        i++;
        //c.drawText("i is: " + i, 50, 100, mIdPaint);
        smile += e.getIsSmilingProbability();
        le += e.getIsLeftEyeOpenProbability();
        re += e.getIsRightEyeOpenProbability();

        int sample = 10; //0.5 sec
        if (i == sample) {
            // calculate an average
            smile /= sample;
            le /= sample;
            re /= sample;

            //printValuesOfFace(c, e);
            saveToPrefs(cont, "id", e.getId() + "");
            saveToPrefs(cont, "smile", smile + "");
            saveToPrefs(cont, "le", le + "");
            saveToPrefs(cont, "re", re + "");
            // reset values
            smile = 0; le = 0; re = 0;
            i = 0;
        }
    }

    public static void saveToPrefs(Context context, String key, String value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key,value);
        editor.commit();
    }
}