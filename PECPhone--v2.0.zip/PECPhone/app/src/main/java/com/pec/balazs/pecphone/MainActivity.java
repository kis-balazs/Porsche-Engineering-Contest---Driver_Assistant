package com.pec.balazs.pecphone;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.pec.balazs.pecphone.face_recognition.VideoFaceDetectionActivity;

public class MainActivity extends AppCompatActivity {

    TextView v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        v = findViewById(R.id.tw);
        loadPrevValues();
    }

    // on clicking the button of "Activate right before driving!"
    public void onVideoFromCameraClick(View view) {
        Intent intent = new Intent(this, VideoFaceDetectionActivity.class);
        startActivity(intent);
        recreate();
    }

    public static String getFromPrefs(Context context, String key, String defaultValue) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        try {
            return sharedPrefs.getString(key, defaultValue);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    public void loadPrevValues() {
        int id = Integer.parseInt(getFromPrefs(getBaseContext(), "id", ""));
        float smile = Float.parseFloat(getFromPrefs(getBaseContext(), "smile", ""));
        float le = Float.parseFloat(getFromPrefs(getBaseContext(), "le", ""));
        float re = Float.parseFloat(getFromPrefs(getBaseContext(), "re", ""));
        float z = Float.parseFloat(getFromPrefs(getBaseContext(), "z", ""));

        int look_away = 100;
        int leClosed = 0, reClosed = 0;
        int smiling = 0;

        //drastically looking away
        if (Math.abs(z) > 5) {
            look_away = 0;
        }
        leClosed = Math.round(le * 100);
        reClosed = Math.round(re * 100);

        smiling = Math.round(smile * 100);

        double res = (look_away + leClosed + reClosed + smiling) * 1.0 / 4.0;
        v.setText("Attention score: " + (res < 0 ? 0 : res));

    }

    /*v.setText("ID of last face is : " + id);
        v.append("\nSmile: " + smile);
        v.append("\nLeft eye: " + le);
        v.append("\nRight eye: " + re);
        v.append("\nface turned: " + z);*/
}
